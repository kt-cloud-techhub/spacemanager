# @kt-cloud-front/ui-style-react

**Figma 기반** 컴포넌트 스타일 패키지입니다.

## 개요

`@kt-cloud-front/ui-style-react`는 **컴포넌트의 CSS 스타일**을 제공합니다. 모든 스타일은 Figma 스펙을 반영하며, Tailwind CSS v4 기반으로 작성되었습니다.

### 🎯 핵심 특징

- **🎨 Figma 기반 스타일** - Figma boundVariables → CSS 변수 자동 매핑
- **📏 정확한 스펙** - Figma 크기, 색상, 간격 100% 일치
- **🌙 다크모드 지원** - `:root[data-mode="dark"]` 자동 적용
- **📦 단일 파일 구조** - 컴포넌트별 `components/[컴포넌트명].css`
- **🎭 Tailwind CSS v4** - 최신 Tailwind 기능 활용

## 🏗️ Architecture: Figma → CSS 매핑

```
Figma 디자인 스펙
        ↓
boundVariables → KCDS 토큰 매핑
        ↓
ui-style-react (CSS)
        ↓
ui-react (완제품 컴포넌트)
```

### Figma 기반 스타일 원칙

- ✅ **Figma boundVariables** → CSS 변수 자동 매핑
- ✅ **Figma 크기, 색상, 간격** → 정확히 일치 (추측 금지)
- ✅ **단일 CSS 파일** - `components/[컴포넌트명].css` (폴더 구조 사용 안 함)
- ✅ **다크모드** - `:root[data-mode="dark"]` 선택자로 자동 지원

## 📁 구조

```
src/
├── index.css          # 전체 통합 (utilities + components + animations)
├── utilities.css      # 유틸리티 헬퍼 클래스
├── components.css     # 44개 컴포넌트 CSS import
├── animations.css     # 애니메이션 preset
└── components/        # 컴포넌트별 단일 CSS 파일 (44개)
    ├── badge.css
    ├── button.css
    └── ... (44개)
```

## 🌍 환경 요구사항

- **Node.js**: `>=22.12.0` (Volta 고정: 22.12.0)
- **pnpm**: `>=10.8.1`
- **Tailwind CSS**: `4.0.0`
- **React**: `19.1.0` (ui-react 사용 시)

## 📚 문서 및 참조

- **전체 프로젝트 가이드**: [`CLAUDE.md`](../../CLAUDE.md)
- **Tailwind CSS v4**: [Tailwind CSS](https://tailwindcss.com)
- **개발 정책**: [`.claude/policies/style-generation-policy.md`](../../.claude/policies/style-generation-policy.md)

## 🔗 관련 패키지

- [`@kt-cloud-front/ui-react`](../ui-react/README.md) - 완제품 컴포넌트 ⭐ **이 스타일 자동 포함**
- [`@kt-cloud-front/ui-core-react`](../ui-core-react/README.md) - Headless UI
- [`@kt-cloud-front/ui-style`](../ui-style/README.md) - 디자인 토큰 (CSS 변수)

---

**Last Updated**: 2025-12-10
