# @kt-cloud-front/ui-react-grid

AG Grid React Wrapper 컴포넌트 패키지

## 설치

```bash
# AG Grid 패키지와 함께 설치
pnpm add @kt-cloud-front/ui-react-grid ag-grid-community ag-grid-react

# Enterprise 기능 사용 시
pnpm add ag-grid-enterprise
```

## API

### SDataGrid Props

| Prop | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `height` | `number \| string` | `400` | Grid 높이 |
| `width` | `number \| string` | `'100%'` | Grid 너비 |
| `themeClass` | `string` | `'ag-theme-quartz'` | CSS 테마 클래스명 |
| `className` | `string` | - | 추가 CSS 클래스 |
| `theme` | `Theme` | - | AG Grid v33+ 테마 옵션 (`'legacy'` 권장) |

> **Note**: `SDataGridProps`는 `AgGridReactProps`를 확장하므로 AG Grid의 모든 props를 사용할 수 있습니다.

## 사용법

### 1. CSS import

```tsx
// 앱 진입점에서 AG Grid 스타일 import
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-quartz.css'

// KCDS 테마 사용 시 (선택)
import '@kt-cloud-front/ui-style-react/components.css'
```

### 2. 모듈 등록

```tsx
// 앱 진입점에서 1회 호출
import { registerGridModules } from '@kt-cloud-front/ui-react-grid'
registerGridModules()
```

### 3. 컴포넌트 사용

```tsx
import { SDataGrid, type ColDef } from '@kt-cloud-front/ui-react-grid'

interface RowData {
  id: number
  name: string
}

const columnDefs: ColDef<RowData>[] = [
  { field: 'id', headerName: 'ID' },
  { field: 'name', headerName: '이름' },
]

const rowData: RowData[] = [
  { id: 1, name: '김철수' },
  { id: 2, name: '이영희' },
]

function MyGrid() {
  return (
    <SDataGrid<RowData>
      theme="legacy"
      rowData={rowData}
      columnDefs={columnDefs}
      height={400}
    />
  )
}
```

### KCDS 테마 적용

KCDS 디자인 토큰 기반 스타일을 적용하려면:

```tsx
import 'ag-grid-community/styles/ag-grid.css'
import 'ag-grid-community/styles/ag-theme-quartz.css'
import '@kt-cloud-front/ui-style-react/components.css'

<SDataGrid<RowData>
  theme="legacy"
  themeClass="ag-theme-quartz kcds-data-grid"
  rowData={rowData}
  columnDefs={columnDefs}
  height={400}
  pagination={true}
  paginationPageSize={10}
  paginationPageSizeSelector={[10, 20, 50]}
/>
```

> **AG Grid v33+ 주의사항**: `theme="legacy"` prop은 CSS 파일 기반 테마를 사용하기 위해 필요합니다. 이 설정 없이 `themeClass`만 사용하면 AG Grid의 새로운 Theming API와 충돌이 발생합니다.

### Enterprise 기능

Enterprise 라이선스가 있는 경우:

```tsx
import { GridEnterpriseProvider } from '@kt-cloud-front/ui-react-grid'
import { LicenseManager } from 'ag-grid-enterprise'
import { ExcelExportModule } from 'ag-grid-enterprise'

// 라이선스 설정
LicenseManager.setLicenseKey('YOUR_LICENSE_KEY')

// Provider로 감싸기
<GridEnterpriseProvider licenseKey="YOUR_KEY" modules={[ExcelExportModule]}>
  <App />
</GridEnterpriseProvider>
```

## Export 목록

```tsx
// Components
export { SDataGrid } from './components'
export type { SDataGridProps } from './components'

// Context
export { GridEnterpriseProvider, useGridEnterprise } from './context'
export type { GridEnterpriseContextValue, GridEnterpriseProviderProps } from './context'

// Utils
export { registerGridModules } from './utils'

// Re-export AG Grid types
export type { ColDef, GridOptions, GridApi, Module } from 'ag-grid-community'
export { AllCommunityModule, ModuleRegistry } from 'ag-grid-community'
```
