# @kt-cloud-front/ui-common

kt cloud front 디자인 시스템의 공통 유틸리티 패키지입니다.

## 개요

`@kt-cloud-front/ui-common`은 모든 UI 패키지에서 공통으로 사용되는 유틸리티 함수와 애니메이션 라이브러리를 제공합니다.

## 🌍 환경 요구사항

- **Node.js**: `>=22.12.0` (Volta 고정: 22.12.0)
- **pnpm**: `>=10.8.1`
- **TypeScript**: `5.8.2`

## 📚 문서 및 참조

- **전체 프로젝트 가이드**: [`CLAUDE.md`](../../CLAUDE.md)
- **개발 정책**: [`.claude/policies/`](../../.claude/policies/)

## 🔗 관련 패키지

- [`@kt-cloud-front/ui-core-react`](../ui-core-react/README.md) - Headless UI 컴포넌트
- [`@kt-cloud-front/ui-react`](../ui-react/README.md) - 완제품 컴포넌트
- [`@kt-cloud-front/ui-style`](../ui-style/README.md) - 디자인 토큰 및 CSS
- [`@kt-cloud-front/ui-style-react`](../ui-style-react/README.md) - Tailwind CSS v4 스타일

---

**Last Updated**: 2025-12-10
