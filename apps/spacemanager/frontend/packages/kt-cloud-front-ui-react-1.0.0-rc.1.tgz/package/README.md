# @kt-cloud-front/ui-react

kt cloud front 디자인 시스템의 React 컴포넌트 라이브러리입니다.

## 개요

`@kt-cloud-front/ui-react`는 **완제품 React 컴포넌트**를 제공하며, Figma 기반 자동화 워크플로우와 Multi-Agent 시스템을 통해 개발됩니다. Headless UI 패턴과 Tailwind CSS v4를 기반으로 설계되었습니다.

### 🎯 핵심 특징

- **🤖 AI-Powered Component Generation** - Multi-Agent 시스템으로 컴포넌트 자동 생성
- **🎨 Figma 기반 개발** - Figma 스펙을 자동으로 동기화하여 디자인 일관성 보장
- **♿ 접근성 우선** - ARIA 표준 준수 및 키보드 네비게이션 지원
- **🌙 다크모드 지원** - CSS 변수 기반 테마 시스템
- **📖 Storybook 문서화** - 모든 컴포넌트에 대한 인터랙티브 문서

## 🏗️ Architecture Highlights

### Headless UI Pattern (로직 ↔ 스타일 분리)

```
ui-core-react (C접두사)     → 순수 로직 (Headless UI)
        ↓
ui-style-react              → CSS 스타일 (Tailwind CSS v4)
        ↓
ui-react (S접두사)          → 완제품 컴포넌트 (Core + Style 조합)
```

### 기술 스택

- **React** 19.1.0
- **TypeScript** 5.8.2
- **Tailwind CSS** v4.0.0
- **Storybook** 9.1.10
- **Radix UI** Primitives
- **Vitest** 3.1.1 + Testing Library

## 🌍 환경 요구사항

- **Node.js**: `>=22.12.0` (Volta 고정: 22.12.0)
- **pnpm**: `>=10.8.1`
- **지원 환경**: 최신 브라우저 (Chrome, Firefox, Safari, Edge)

## 📚 문서 및 참조

- **전체 프로젝트 가이드**: [`CLAUDE.md`](../../CLAUDE.md)
- **MCP 서버 시스템**: [`mcp/README.md`](../../mcp/README.md)
- **개발 정책**: [`.claude/policies/`](../../.claude/policies/)
- **Storybook**: [http://localhost:6006](http://localhost:6006) (개발 서버 실행 후)

## 🔗 관련 패키지

- [`@kt-cloud-front/ui-core-react`](../ui-core-react/README.md) - Headless UI 컴포넌트 (31개)
- [`@kt-cloud-front/ui-style-react`](../ui-style-react/README.md) - Tailwind CSS v4 스타일
- [`@kt-cloud-front/ui-common`](../ui-common/README.md) - 공통 유틸리티 및 타입

---

**Last Updated**: 2025-12-10
