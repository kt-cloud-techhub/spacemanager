# @kt-cloud-front/ui-core-react

**Headless UI** kt cloud front 디자인 시스템의 핵심 React 컴포넌트 라이브러리입니다.

## 개요

`@kt-cloud-front/ui-core-react`는 **31개의 Headless UI 컴포넌트**를 제공합니다. 순수 로직만 제공하고 스타일은 포함하지 않습니다.

### 🎯 핵심 특징

- **🎭 Headless UI 패턴** - 순수 로직만 제공, 스타일 없음 (ui-style-react와 조합)
- **🎨 Shadcn 기반** - [shadcn/ui](https://ui.shadcn.com) 패턴을 따르는 컴포넌트
- **C 접두사** - 모든 컴포넌트는 C로 시작 (예: CButton, CModal, CCheckbox)
- **♿ 접근성 우선** - Radix UI 프리미티브 기반, ARIA 표준 준수
- **⌨️ 키보드 네비게이션** - 모든 인터랙티브 컴포넌트 지원
- **`data-*` 속성** - 상태를 data 속성으로 전달 (예: `data-state`, `data-disabled`)

## 🏗️ Architecture: Headless UI Pattern

Headless UI는 **로직과 스타일을 완전히 분리**하는 패턴입니다:

```
ui-core-react (C접두사)     → 순수 로직만 (상태 관리, 이벤트, 접근성)
        ↓
ui-style-react              → CSS 스타일 (Tailwind CSS v4)
        ↓
ui-react (S접두사)          → 완제품 컴포넌트 (Core + Style 조합)
```

### 왜 Headless UI인가?

- ✅ **재사용성**: 동일한 로직에 다양한 스타일 적용 가능
- ✅ **유연성**: 프로젝트별 디자인 시스템에 맞게 커스터마이징
- ✅ **유지보수성**: 로직과 스타일을 독립적으로 수정 가능
- ✅ **테스트 용이성**: 로직만 단위 테스트 가능

## 🌍 환경 요구사항

- **Node.js**: `>=22.12.0` (Volta 고정: 22.12.0)
- **pnpm**: `>=10.8.1`
- **React**: `19.1.0`
- **TypeScript**: `5.8.2`

## 📚 문서 및 참조

- **전체 프로젝트 가이드**: [`CLAUDE.md`](../../CLAUDE.md)
- **Shadcn 패턴**: [shadcn/ui](https://ui.shadcn.com/docs/components)
- **Radix UI**: [Radix Primitives](https://www.radix-ui.com/primitives)
- **개발 정책**: [`.claude/policies/`](../../.claude/policies/)

## 🔗 관련 패키지

- [`@kt-cloud-front/ui-react`](../ui-react/README.md) - 완제품 컴포넌트 ⭐ **스타일 포함**
- [`@kt-cloud-front/ui-style-react`](../ui-style-react/README.md) - CSS 스타일
- [`@kt-cloud-front/ui-common`](../ui-common/README.md) - 공통 유틸리티

---

**Last Updated**: 2025-12-10
